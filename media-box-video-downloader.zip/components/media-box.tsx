'use client'

import { useRef, useState } from 'react'
import { FFmpeg } from '@ffmpeg/ffmpeg'
import { fetchFile, toBlobURL } from '@ffmpeg/util'
import { Download, Link2, Loader2, CheckCircle2, AlertCircle } from 'lucide-react'

// الصيغ المدعومة
type Format = 'mp4' | 'mp3' | 'm4a'

const FORMATS: { id: Format; label: string; kind: 'فيديو' | 'صوت' }[] = [
  { id: 'mp4', label: 'MP4', kind: 'فيديو' },
  { id: 'mp3', label: 'MP3', kind: 'صوت' },
  { id: 'm4a', label: 'M4A', kind: 'صوت' },
]

// نسخة core ثابتة عشان نضمن الاستقرار
const CORE_BASE = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd'

type Status = 'idle' | 'downloading' | 'converting' | 'done' | 'error'

export function MediaBox() {
  const [url, setUrl] = useState('')
  const [format, setFormat] = useState<Format>('mp4')
  const [status, setStatus] = useState<Status>('idle')
  const [progress, setProgress] = useState(0)
  const [message, setMessage] = useState('')

  const ffmpegRef = useRef<FFmpeg | null>(null)

  const busy = status === 'downloading' || status === 'converting'

  // تحميل ffmpeg مرة واحدة بس
  async function getFFmpeg() {
    if (ffmpegRef.current) return ffmpegRef.current
    const ffmpeg = new FFmpeg()
    ffmpeg.on('progress', ({ progress: p }) => {
      // نخلي التحويل من 50% لـ 100%
      setProgress(50 + Math.min(Math.max(p, 0), 1) * 50)
    })
    await ffmpeg.load({
      coreURL: await toBlobURL(`${CORE_BASE}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${CORE_BASE}/ffmpeg-core.wasm`, 'application/wasm'),
    })
    ffmpegRef.current = ffmpeg
    return ffmpeg
  }

  // تحميل الملف من اللينك مع متابعة نسبة التقدم
  async function downloadWithProgress(fileUrl: string): Promise<Blob> {
    const res = await fetch(fileUrl)
    if (!res.ok) throw new Error(`السيرفر رجّع كود ${res.status}`)

    const total = Number(res.headers.get('Content-Length')) || 0
    const reader = res.body?.getReader()
    if (!reader) return await res.blob()

    const chunks: Uint8Array[] = []
    let received = 0

    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      if (value) {
        chunks.push(value)
        received += value.length
        if (total) {
          // التحميل ياخد أول 50% من البار (لو هنحوّل)
          const ratio = received / total
          setProgress(format === 'mp4' ? ratio * 100 : ratio * 50)
        }
      }
    }
    return new Blob(chunks as BlobPart[])
  }

  function saveBlob(blob: Blob, filename: string) {
    const link = document.createElement('a')
    link.href = URL.createObjectURL(blob)
    link.download = filename
    document.body.appendChild(link)
    link.click()
    link.remove()
    URL.revokeObjectURL(link.href)
  }

  async function handleDownload() {
    const trimmed = url.trim()
    if (!trimmed) {
      setStatus('error')
      setMessage('لازم تحط لينك الأول')
      return
    }
    if (!/^https?:\/\//i.test(trimmed)) {
      setStatus('error')
      setMessage('اللينك لازم يبدأ بـ http أو https')
      return
    }

    try {
      setProgress(0)
      setStatus('downloading')
      setMessage('بنزّل الملف من اللينك...')

      const sourceBlob = await downloadWithProgress(trimmed)
      const baseName = `mediabox-${Date.now()}`

      // MP4: نحفظ الملف زي ما هو على طول
      if (format === 'mp4') {
        setProgress(100)
        saveBlob(sourceBlob, `${baseName}.mp4`)
        setStatus('done')
        setMessage('تم! اتحفظ الفيديو على جهازك.')
        return
      }

      // MP3 / M4A: نستخرج الصوت بـ ffmpeg.wasm
      setStatus('converting')
      setMessage(`بنحوّل لـ ${format.toUpperCase()}... (ممكن ياخد شوية)`)

      const ffmpeg = await getFFmpeg()
      await ffmpeg.writeFile('input', await fetchFile(sourceBlob))

      const outName = `output.${format}`
      const args =
        format === 'mp3'
          ? ['-i', 'input', '-vn', '-b:a', '192k', outName]
          : ['-i', 'input', '-vn', '-c:a', 'aac', '-b:a', '192k', outName]

      await ffmpeg.exec(args)

      const data = (await ffmpeg.readFile(outName)) as Uint8Array
      const mime = format === 'mp3' ? 'audio/mpeg' : 'audio/mp4'
      const outBlob = new Blob([data.buffer as ArrayBuffer], { type: mime })

      setProgress(100)
      saveBlob(outBlob, `${baseName}.${format}`)
      setStatus('done')
      setMessage('تم! اتحفظ الصوت على جهازك.')
    } catch (err) {
      console.log('[v0] download error:', err)
      setStatus('error')
      const msg = err instanceof Error ? err.message : 'حصل خطأ غير متوقع'
      setMessage(
        `فشل التحميل: ${msg}. غالبًا اللينك مش بيسمح بالتحميل المباشر (CORS) أو غلط.`,
      )
    }
  }

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 py-8">
      {/* الهيدر */}
      <header className="mb-8 text-center">
        <div className="mb-3 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/15 text-primary">
          <Download className="h-7 w-7" aria-hidden="true" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-balance">MediaBox</h1>
        <p className="mt-1 text-sm leading-relaxed text-muted-foreground text-pretty">
          نزّل فيديو وصوت من أي لينك مباشر — كله في المتصفح
        </p>
      </header>

      {/* الكارت الرئيسي */}
      <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        {/* خانة اللينك */}
        <label htmlFor="url" className="mb-2 block text-sm font-medium">
          لينك الملف
        </label>
        <div className="relative">
          <Link2
            className="pointer-events-none absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground"
            aria-hidden="true"
          />
          <input
            id="url"
            type="url"
            inputMode="url"
            dir="ltr"
            placeholder="https://example.com/video.mp4"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            disabled={busy}
            className="w-full rounded-xl border border-input bg-background py-3 pr-11 pl-3 text-sm text-foreground outline-none transition placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/30 disabled:opacity-60"
          />
        </div>

        {/* اختيار الصيغة */}
        <p className="mb-2 mt-5 text-sm font-medium">الصيغة</p>
        <div className="grid grid-cols-3 gap-2">
          {FORMATS.map((f) => {
            const active = format === f.id
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFormat(f.id)}
                disabled={busy}
                aria-pressed={active}
                className={`flex flex-col items-center gap-0.5 rounded-xl border py-3 text-sm font-semibold transition disabled:opacity-60 ${
                  active
                    ? 'border-primary bg-primary/15 text-primary'
                    : 'border-border bg-background text-foreground hover:border-primary/50'
                }`}
              >
                {f.label}
                <span className="text-[11px] font-normal text-muted-foreground">
                  {f.kind}
                </span>
              </button>
            )
          })}
        </div>

        {/* زرار التحميل */}
        <button
          type="button"
          onClick={handleDownload}
          disabled={busy}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 text-base font-bold text-primary-foreground transition active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-70"
        >
          {busy ? (
            <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
          ) : (
            <Download className="h-5 w-5" aria-hidden="true" />
          )}
          {busy ? 'جاري التحميل...' : 'تحميل'}
        </button>

        {/* شريط نسبة التقدم */}
        {(busy || status === 'done') && (
          <div className="mt-5">
            <div className="mb-1.5 flex items-center justify-between text-xs text-muted-foreground">
              <span>{status === 'converting' ? 'تحويل' : status === 'done' ? 'اكتمل' : 'تحميل'}</span>
              <span dir="ltr">{Math.round(progress)}%</span>
            </div>
            <div
              className="h-2.5 w-full overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-valuenow={Math.round(progress)}
              aria-valuemin={0}
              aria-valuemax={100}
            >
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-200"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* رسالة الحالة */}
        {message && (
          <div
            className={`mt-4 flex items-start gap-2 rounded-xl px-3 py-2.5 text-sm leading-relaxed ${
              status === 'error'
                ? 'bg-destructive/15 text-destructive'
                : status === 'done'
                  ? 'bg-primary/15 text-primary'
                  : 'bg-muted text-muted-foreground'
            }`}
            role="status"
          >
            {status === 'error' ? (
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            ) : status === 'done' ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            ) : null}
            <span>{message}</span>
          </div>
        )}
      </section>

      <p className="mt-4 px-1 text-center text-xs leading-relaxed text-muted-foreground">
        ملاحظة: اللينك لازم يكون مباشر وبيسمح بالتحميل (CORS). التحويل لـ MP3/M4A بيتم على جهازك.
      </p>

      {/* مساحة الإعلان */}
      <div className="mt-auto pt-8">
        <div className="flex h-24 w-full items-center justify-center rounded-xl border border-dashed border-border bg-card/50 text-sm font-medium tracking-wide text-muted-foreground">
          AD BANNER HERE
        </div>
      </div>
    </main>
  )
}
